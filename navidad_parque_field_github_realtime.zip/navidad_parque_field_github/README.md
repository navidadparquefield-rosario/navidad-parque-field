# Navidad Parque Field

Sistema de gestión del proyecto Navidad Parque Field conectado a Supabase.

## Archivos principales

- `index.html`: aplicación principal.
- `sql/schema.sql`: estructura base de Supabase.
- `sql/realtime.sql`: activación de Supabase Realtime.

## Configuración

El archivo `index.html` ya contiene la URL y anon key pública de Supabase.

## Realtime

Para que los cambios se vean en varias computadoras al mismo tiempo, ejecutar `sql/realtime.sql` en Supabase SQL Editor.

Tablas sincronizadas:

- tasks
- subtasks
- comments
- attachments
- activity_log
