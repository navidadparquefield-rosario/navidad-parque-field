-- Ejecutar en Supabase SQL Editor para activar Realtime en las tablas principales
-- Si alguna tabla ya está agregada, Supabase puede devolver aviso de duplicado; no pasa nada.

alter publication supabase_realtime add table public.tasks;
alter publication supabase_realtime add table public.subtasks;
alter publication supabase_realtime add table public.comments;
alter publication supabase_realtime add table public.attachments;
alter publication supabase_realtime add table public.activity_log;

-- Recomendado para que Realtime reciba datos completos en updates/deletes
alter table public.tasks replica identity full;
alter table public.subtasks replica identity full;
alter table public.comments replica identity full;
alter table public.attachments replica identity full;
alter table public.activity_log replica identity full;
