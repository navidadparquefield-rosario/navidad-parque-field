-- Navidad Parque Field - Supabase schema v1.4
-- Ejecutar en Supabase SQL Editor.
-- Preparado para tareas, subtareas, comentarios, adjuntos por referencia y actividad.

create extension if not exists pgcrypto;

-- Limpieza segura opcional: NO ejecutar si ya tenés datos reales.
-- drop table if exists public.activity_log, public.attachments, public.comments, public.subtasks, public.tasks, public.board_columns, public.project_members, public.profiles, public.projects cascade;

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  icon text default '🎄',
  description text,
  target_date timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid unique,
  full_name text not null,
  role text,
  initials text,
  color text default '#7c3aed',
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.project_members (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  permission text not null default 'editor' check (permission in ('admin','editor','viewer','guest')),
  created_at timestamptz not null default now(),
  unique(project_id, profile_id)
);

create table if not exists public.board_columns (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  name text not null,
  position int not null default 0,
  is_done boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(project_id, name)
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  column_id uuid references public.board_columns(id) on delete set null,
  title text not null,
  description text,
  assignee_id uuid references public.profiles(id) on delete set null,
  priority text not null default 'Media' check (priority in ('Baja','Media','Alta','Urgente')),
  tag text,
  start_date date,
  due_date date,
  is_done boolean not null default false,
  position int not null default 0,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.subtasks (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  title text not null,
  assignee_id uuid references public.profiles(id) on delete set null,
  due_date date,
  is_done boolean not null default false,
  position int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  profile_id uuid references public.profiles(id) on delete set null,
  body text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Adjuntos livianos: el archivo va a Supabase Storage / Drive / URL externa.
-- La base guarda solo la referencia.
create table if not exists public.attachments (
  id uuid primary key default gen_random_uuid(),
  task_id uuid references public.tasks(id) on delete cascade,
  subtask_id uuid references public.subtasks(id) on delete cascade,
  name text not null,
  file_url text not null,
  file_type text,
  file_size bigint,
  storage_bucket text,
  storage_path text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  check (task_id is not null or subtask_id is not null)
);

create table if not exists public.activity_log (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  task_id uuid references public.tasks(id) on delete cascade,
  subtask_id uuid references public.subtasks(id) on delete cascade,
  profile_id uuid references public.profiles(id) on delete set null,
  action text not null,
  detail text,
  created_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_projects_updated_at on public.projects;
create trigger trg_projects_updated_at before update on public.projects for each row execute function public.set_updated_at();

drop trigger if exists trg_profiles_updated_at on public.profiles;
create trigger trg_profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();

drop trigger if exists trg_board_columns_updated_at on public.board_columns;
create trigger trg_board_columns_updated_at before update on public.board_columns for each row execute function public.set_updated_at();

drop trigger if exists trg_tasks_updated_at on public.tasks;
create trigger trg_tasks_updated_at before update on public.tasks for each row execute function public.set_updated_at();

drop trigger if exists trg_subtasks_updated_at on public.subtasks;
create trigger trg_subtasks_updated_at before update on public.subtasks for each row execute function public.set_updated_at();

drop trigger if exists trg_comments_updated_at on public.comments;
create trigger trg_comments_updated_at before update on public.comments for each row execute function public.set_updated_at();

-- Función para que, cuando todas las subtareas estén finalizadas, la tarea pueda marcarse como finalizada automáticamente.
create or replace function public.sync_task_done_from_subtasks()
returns trigger language plpgsql as $$
declare
  target_task uuid;
  total_count int;
  done_count int;
begin
  target_task := coalesce(new.task_id, old.task_id);

  select count(*), count(*) filter (where is_done)
  into total_count, done_count
  from public.subtasks
  where task_id = target_task;

  if total_count > 0 and total_count = done_count then
    update public.tasks
    set is_done = true,
        column_id = (
          select id from public.board_columns
          where project_id = public.tasks.project_id and is_done = true
          order by position asc
          limit 1
        )
    where id = target_task;
  end if;

  return coalesce(new, old);
end;
$$;

drop trigger if exists trg_subtasks_sync_task_done on public.subtasks;
create trigger trg_subtasks_sync_task_done
  after insert or update of is_done or delete on public.subtasks
  for each row execute function public.sync_task_done_from_subtasks();

-- Índices para que el tablero cargue rápido.
create index if not exists idx_board_columns_project_position on public.board_columns(project_id, position);
create index if not exists idx_tasks_project_column_position on public.tasks(project_id, column_id, position);
create index if not exists idx_tasks_assignee on public.tasks(assignee_id);
create index if not exists idx_subtasks_task_position on public.subtasks(task_id, position);
create index if not exists idx_comments_task_created on public.comments(task_id, created_at desc);
create index if not exists idx_activity_project_created on public.activity_log(project_id, created_at desc);

-- Datos iniciales
insert into public.projects (name, icon, description, target_date)
select 'Navidad Parque Field', '🎄', 'Gestión integral del proyecto', '2026-12-25 00:00:00-03'
where not exists (select 1 from public.projects where name = 'Navidad Parque Field');

with p as (select id from public.projects where name = 'Navidad Parque Field' limit 1)
insert into public.board_columns (project_id, name, position, is_done)
select p.id, x.name, x.position, x.is_done
from p, (values
  ('Ideas', 1, false),
  ('Por hacer', 2, false),
  ('En diseño', 3, false),
  ('Esperando aprobación', 4, false),
  ('Programado', 5, false),
  ('Publicado', 6, false),
  ('Finalizadas', 7, true)
) as x(name, position, is_done)
on conflict (project_id, name) do nothing;

insert into public.profiles (full_name, role, initials, color)
values
  ('Omar', 'Director', 'O', '#7c3aed'),
  ('Marta', 'Coordinación', 'M', '#16a34a'),
  ('Juan', 'Contenido', 'J', '#2563eb'),
  ('Pablo', 'Producción', 'P', '#f97316'),
  ('Matías', 'Community Manager', 'ML', '#dc2626')
on conflict do nothing;

-- RLS listo para activar más adelante, cuando conectemos Supabase Auth.
-- alter table public.projects enable row level security;
-- alter table public.profiles enable row level security;
-- alter table public.project_members enable row level security;
-- alter table public.board_columns enable row level security;
-- alter table public.tasks enable row level security;
-- alter table public.subtasks enable row level security;
-- alter table public.comments enable row level security;
-- alter table public.attachments enable row level security;
-- alter table public.activity_log enable row level security;
